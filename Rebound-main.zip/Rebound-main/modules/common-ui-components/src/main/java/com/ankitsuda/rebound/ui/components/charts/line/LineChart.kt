/*
 * Copyright (c) 2022 Ankit Suda.
 *
 * Licensed under the GNU General Public License v3
 *
 * This is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 */

package com.ankitsuda.rebound.ui.components.charts.line

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateDrawableArea
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateFillPath
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateLinePath
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculatePointLocation
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateXAxisDrawableArea
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateXAxisLabelsDrawableArea
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.calculateYAxisDrawableArea
import com.ankitsuda.rebound.ui.components.charts.line.LineChartUtils.withProgress
import com.ankitsuda.rebound.ui.components.charts.line.renderer.line.LineDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.line.LineShader
import com.ankitsuda.rebound.ui.components.charts.line.renderer.line.NoLineShader
import com.ankitsuda.rebound.ui.components.charts.line.renderer.line.SolidLineDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.point.FilledCircularPointDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.point.PointDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.xaxis.SimpleXAxisDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.xaxis.XAxisDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.yaxis.SimpleYAxisDrawer
import com.ankitsuda.rebound.ui.components.charts.line.renderer.yaxis.YAxisDrawer
import com.github.tehras.charts.piechart.animation.simpleChartAnimation

@Composable
fun LineChart(
  lineChartData: LineChartData,
  modifier: Modifier = Modifier,
  animation: AnimationSpec<Float> = simpleChartAnimation(),
  pointDrawer: PointDrawer = FilledCircularPointDrawer(),
  lineDrawer: LineDrawer = SolidLineDrawer(),
  lineShader: LineShader = NoLineShader,
  xAxisDrawer: XAxisDrawer = SimpleXAxisDrawer(),
  yAxisDrawer: YAxisDrawer = SimpleYAxisDrawer(),
  horizontalOffset: Float = 5f
) {
  check(horizontalOffset in 0f..25f) {
    "Horizontal offset is the % offset from sides, " +
      "and should be between 0%-25%"
  }

  val transitionAnimation = remember(lineChartData.points) { Animatable(initialValue = 0f) }

  LaunchedEffect(lineChartData.points) {
    transitionAnimation.snapTo(0f)
    transitionAnimation.animateTo(1f, animationSpec = animation)
  }

  Canvas(modifier = modifier.fillMaxSize()) {
    drawIntoCanvas { canvas ->
      val yAxisDrawableArea = calculateYAxisDrawableArea(
        xAxisLabelSize = xAxisDrawer.requiredHeight(this),
        size = size
      )
      val xAxisDrawableArea = calculateXAxisDrawableArea(
        yAxisWidth = yAxisDrawableArea.width,
        labelHeight = xAxisDrawer.requiredHeight(this),
        size = size
      )
      val xAxisLabelsDrawableArea = calculateXAxisLabelsDrawableArea(
        xAxisDrawableArea = xAxisDrawableArea,
        offset = horizontalOffset
      )
      val chartDrawableArea = calculateDrawableArea(
        xAxisDrawableArea = xAxisDrawableArea,
        yAxisDrawableArea = yAxisDrawableArea,
        size = size,
        offset = horizontalOffset
      )

      // Draw the chart line.
      lineDrawer.drawLine(
        drawScope = this,
        canvas = canvas,
        linePath = calculateLinePath(
          drawableArea = chartDrawableArea,
          lineChartData = lineChartData,
          transitionProgress = transitionAnimation.value
        )
      )

      lineShader.fillLine(
        drawScope = this,
        canvas = canvas,
        fillPath = calculateFillPath(
          drawableArea = chartDrawableArea,
          lineChartData = lineChartData,
          transitionProgress = transitionAnimation.value
        )
      )

      lineChartData.points.forEachIndexed { index, point ->
        withProgress(
          index = index,
          lineChartData = lineChartData,
          transitionProgress = transitionAnimation.value
        ) {
          pointDrawer.drawPoint(
            drawScope = this,
            canvas = canvas,
            center = calculatePointLocation(
              drawableArea = chartDrawableArea,
              lineChartData = lineChartData,
              point = point,
              index = index
            )
          )
        }
      }

      // Draw the X Axis line.
        xAxisDrawer.drawAxisLine(
          drawScope = this,
          drawableArea = xAxisDrawableArea,
          canvas = canvas
        )


      xAxisDrawer.drawAxisLabels(
        drawScope = this,
        canvas = canvas,
        drawableArea = xAxisLabelsDrawableArea,
        labels = lineChartData.points.map { it.label }
      )

      // Draw the Y Axis line.
        yAxisDrawer.drawAxisLine(
          drawScope = this,
          canvas = canvas,
          drawableArea = yAxisDrawableArea
        )


      yAxisDrawer.drawAxisLabels(
        drawScope = this,
        canvas = canvas,
        drawableArea = yAxisDrawableArea,
        minValue = lineChartData.minYValue,
        maxValue = lineChartData.maxYValue
      )


    }
  }
}
